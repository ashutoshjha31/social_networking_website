<html>
  <head>
    <title>Query Form</title>
    <style>
      
      body {
        background-color: #eafde7; 
        font-family: sans-serif;
        margin: 40px;
      }

      label {
        color: #555; 
        display: block;
        margin-bottom: 5px;
      }

      input[type="text"],
      input[type="password"],
      select {
        width: 200px;
        padding: 10px;
        border: 1px solid #ccc;
        margin-bottom: 10px;
        border-radius: 5px; 
      }

      button {
        background-color: #4a90e2;
        color: #fff;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        border-radius: 5px;
      }

      
      .box {
        background-color: #fff; 
        border: 2px solid #b5e4f7;
        padding: 15px; 
        border-radius: 10px;
        box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.1);
        background-image: linear-gradient(to right, #eafde7, #c7fdb5); 
        width: 300px; 
      }

     
      h1 {
        text-align: center;
        color: #333;
      }
       form {
        width: 300px;
        margin: 0 auto;
      }
    </style>
  </head>
  <body>
<h1>Submit a Query</h1>
<center><div class="box">
<form action="submit_query.php" method="post">
  <label for="name">Your Name:</label>
  <input type="text" id="name" name="username" placeholder="Enter your Name here" required><br><br>

  <label for="email">Your Email:</label>
  <input type="email" id="email" name="email" placeholder=" Enter your E-mail here" required><br><br>

  <label for="query">Your Query:</label><br>
  <textarea id="query" name="query" rows="5"  placeholder=" Write your Query..."required></textarea><br><br>

  <button type="submit">Submit Query</button>
</form>
</center></div></body>
</html>


<?php


$conn = new mysqli('localhost', 'root', '2004', 'trainee');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$username = isset($_POST['username']) ? $_POST['username'] : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';
$query = isset($_POST['query']) ? $_POST['query'] : '';

$sql = "INSERT INTO trainee (username, email, query) VALUES ('$username', '$email', '$query')";

if ($conn->query($sql) === TRUE) {
    echo "Query submitted successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
