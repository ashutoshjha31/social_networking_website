<?php
$login=false;
$showError=false;
if($_SERVER["REQUEST_METHOD"]=="POST"){
include 'partials/_dbconnect.php';
  $username=$_POST["username"];

  $password=$_POST["password"];
  


    $sql="Select * from users where username='$username' AND password='$password' ";

    $result=mysqli_query($conn,$sql);
    $num=mysqli_result($result);
    if($num==1){
      $login=true;
    }
    else{
        $showError="Invalid Credentials";
    }
  }

?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>Login</title>


</head>
<body>

<?php require'partials/_nav.php'?>
<?php require'partials/_dark.php'?>

<?php

if($login){
echo '
<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong>SUCCESS!</strong> You are logged in.
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
';
}

if($showError){
    echo '
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>ERROR!</strong>'.$showError.'
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    ';
    }


?>

<div class="container my-4">

<h1 class="text-center">Login to our website</h1>

<form  action="/TATA_PARIKSHAN/login.php" method="post">
  


  <div class="form-group col-md-6">
    <label for="exampleInputPassword1" class="form-label" >Username</label>
    <input type="text" class="form-control" id="exampleInputPassword1" name="username">
  </div>



  <div class="form-group col-md-6">
    <label for="exampleInputPassword1" class="form-label" >Password</label>
    <input type="password" class="form-control" id="exampleInputPassword1" name="password">
  </div>

  
  <button type="submit" class="btn btn-primary col-md-6">Login</button>
</form>
</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>
</html>