<!DOCTYPE html>
<html>
<head>
<title>Course Information</title>
<style>
    
    body {
        background-color: #eafde7;
        font-family: sans-serif;
        margin: 40px;
    }
    
  
    h1 {
      font-size: 36px;
      font-weight: 500;
      color: #2196f3;
      margin-bottom: 30px;
    }
  
    p {
      line-height: 1.6;
      margin-bottom: 20px;
    }
  
   
    table {
      border-collapse: collapse;
      width: 100%;
      margin: 40px auto;
      border: 1px solid #ddd;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    }
  
    th, td {
      padding: 10px 15px;
      text-align: left;
      border-bottom: 1px solid #ddd;
    }
  
    tr:nth-child(even) {
      background-color: #f8f9fb;
    }
  
    th {
      background-color: #e9ecef;
      font-weight: 600;
      color: #333;
    }
  
  
    td:nth-child(2) {
      font-family: monospace;
    }
  
    
    td:nth-child(5) {
      width: 50%;
    }
  
    
    h2 {
      font-size: 24px;
      font-weight: 500;
      margin-bottom: 10px;
      color: #2196f3;
    }
  
    a {
      color: #2196f3;
      text-decoration: none;
    }
    button {
        background-color: #4ae266;
        color: #fff;
        padding: 10px 20px;
        border: none;
        cursor: pointer;
        border-radius: 5px;
      }
    
  </style>
</head>
<body>
<center><h1>Registered Users</h1></center>

 <?php

$conn = mysqli_connect("localhost", "root", "2004", "trainee");

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}


$result = $conn->query("SELECT * FROM trainee");

if ($result->num_rows > 0) {
  echo "<table>
          <tr>
              
              <th>Name</th>
              <th>Email</th>
              
          </tr>";

  while ($row = $result->fetch_assoc()) {
      echo "<tr>
             
              <td>{$row['username']}</td>
              <td>{$row['email']}</td>
              
          </tr>";
  }

  echo "</table>";
} else {
  echo "No registered users.";
}

$conn->close();
?> 


    <center><h1>User Queries</h1></center>

    <?php
        
        $conn = new mysqli('localhost', 'root', '2004', 'trainee');

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

      
        $result = $conn-> query("SELECT * FROM trainee");

        if ($result->num_rows > 0) {
            echo "<table>
                    <tr>
                        
                        <th>Name</th>
                        <th>Email</th>
                        <th>Query</th>
                    </tr>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        
                        <td>{$row['username']}</td>
                        <td>{$row['email']}</td>
                        <td>{$row['query']}</td>
                    </tr>";
            }

            echo "</table>";
        } else {
            echo "No user queries.";
        }

        $conn->close();
    ?>
</body>
</html>
</body>
</html>