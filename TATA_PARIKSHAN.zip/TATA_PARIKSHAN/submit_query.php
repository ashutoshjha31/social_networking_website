<?php

$conn = mysqli_connect("localhost", "root", '2004', 'trainee');

$username = $_POST['username'];
$email = $_POST['email'];
$query = $_POST['query'];


$sql = "INSERT INTO query (username,email,query) VALUES ('$username', '$email', '$query')";
mysqli_query($conn, $sql);


echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong>SUCCESS!</strong> You are in.
<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>';


mysqli_close($conn);


?>